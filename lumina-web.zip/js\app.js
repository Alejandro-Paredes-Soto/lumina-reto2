(function () {
  const STORAGE_KEY = "lumina-habits-v1";
  const MAX_HABITS = 3;

  const form = document.getElementById("habit-form");
  const input = document.getElementById("habit-input");
  const list = document.getElementById("habit-list");
  const hint = document.getElementById("form-hint");
  const doneCount = document.getElementById("done-count");
  const totalCount = document.getElementById("total-count");
  const resetBtn = document.getElementById("reset-day");

  function loadHabits() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      const data = raw ? JSON.parse(raw) : [];
      return Array.isArray(data) ? data : [];
    } catch (error) {
      return [];
    }
  }

  function saveHabits(habits) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(habits));
  }

  function uid() {
    return "h-" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }

  function setHint(message) {
    hint.textContent = message || "";
  }

  function render() {
    const habits = loadHabits();
    list.innerHTML = "";

    habits.forEach(function (habit) {
      const li = document.createElement("li");
      li.className = "habit-item" + (habit.done ? " done" : "");

      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.checked = Boolean(habit.done);
      checkbox.setAttribute("aria-label", "Completar " + habit.text);
      checkbox.addEventListener("change", function () {
        habit.done = checkbox.checked;
        saveHabits(habits);
        render();
      });

      const label = document.createElement("span");
      label.className = "habit-label";
      label.textContent = habit.text;

      const del = document.createElement("button");
      del.type = "button";
      del.className = "delete-btn";
      del.textContent = "Eliminar";
      del.addEventListener("click", function () {
        const next = habits.filter(function (item) {
          return item.id !== habit.id;
        });
        saveHabits(next);
        setHint("");
        render();
      });

      li.appendChild(checkbox);
      li.appendChild(label);
      li.appendChild(del);
      list.appendChild(li);
    });

    const done = habits.filter(function (habit) {
      return habit.done;
    }).length;

    doneCount.textContent = String(done);
    totalCount.textContent = String(habits.length);
  }

  form.addEventListener("submit", function (event) {
    event.preventDefault();
    const text = input.value.trim();
    if (!text) {
      return;
    }

    const habits = loadHabits();
    if (habits.length >= MAX_HABITS) {
      setHint("Solo puedes tener " + MAX_HABITS + " hábitos activos. Elimina uno para agregar otro.");
      return;
    }

    habits.push({ id: uid(), text: text, done: false });
    saveHabits(habits);
    input.value = "";
    setHint("");
    render();
  });

  resetBtn.addEventListener("click", function () {
    const habits = loadHabits().map(function (habit) {
      return { id: habit.id, text: habit.text, done: false };
    });
    saveHabits(habits);
    setHint("Día reiniciado. ¡A por otra racha!");
    render();
  });

  render();
})();
